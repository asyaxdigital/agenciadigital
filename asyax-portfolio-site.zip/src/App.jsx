
import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";
import { Megaphone, BarChart2, Image, BadgeCheck } from "lucide-react";

const portfolioImages = [
  "/STORY 1.png",
  "/POST 3.png",
  "/AGRADECIMENTO.png",
  "/BRAHMA 2.png",
  "/DIA DAS MAES - BRINDES GRAFICA 2.png",
  "/FARMSHOW INOVART A4.png",
  "/dia do cafezinho promocao.png",
  "/KIT BOAS VINDAS AZUL PRINT.png"
];

const services = [
  {
    title: "Gestão de Redes Sociais",
    icon: <Megaphone className="w-10 h-10 text-purple-400 mb-4" />,
  },
  {
    title: "Tráfego Pago (Meta Ads)",
    icon: <BarChart2 className="w-10 h-10 text-purple-400 mb-4" />,
  },
  {
    title: "Criação de Criativos",
    icon: <Image className="w-10 h-10 text-purple-400 mb-4" />,
  },
  {
    title: "Branding & Identidade Visual",
    icon: <BadgeCheck className="w-10 h-10 text-purple-400 mb-4" />,
  }
];

export default function Home() {
  return (
    <div className="font-sans bg-[#0e0b1f] text-white">
      {/* Header with Logo */}
      <header className="flex justify-between items-center px-6 py-4 bg-[#0e0b1f]">
        <img src="/1.png" alt="Logo Asyax" className="h-12" />
        <nav className="hidden md:flex gap-6 text-sm">
          <a href="#portfolio" className="hover:text-purple-300">Portfólio</a>
          <a href="#servicos" className="hover:text-purple-300">Serviços</a>
          <a href="#contato" className="hover:text-purple-300">Contato</a>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="text-center py-20 bg-gradient-to-r from-[#150533] via-[#0e0b1f] to-[#051533] text-white">
        <h1 className="text-4xl md:text-5xl font-bold mb-4">
          Transformamos ideias em resultados no digital
        </h1>
        <p className="text-lg md:text-xl max-w-xl mx-auto mb-6">
          Veja na prática como a Asyax entrega criatividade, estratégia e conversão para negócios da região.
        </p>
        <Button className="text-lg px-6 py-3 bg-purple-700 hover:bg-purple-800">Ver Portfólio</Button>
      </section>

      {/* Portfólio Section */}
      <section className="py-16 bg-[#1a1a2e]" id="portfolio">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-purple-100">Portfólio de Social Media</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {portfolioImages.map((src, index) => (
              <motion.div
                key={index}
                whileHover={{ scale: 1.03 }}
                className="rounded-2xl overflow-hidden shadow-lg border border-purple-900"
              >
                <img src={src} alt={`Portfólio ${index}`} className="w-full h-auto" />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Serviços Section */}
      <section className="py-16 bg-[#12101c]" id="servicos">
        <div className="max-w-5xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-10 text-purple-100">O que fazemos por sua marca</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {services.map((service, index) => (
              <Card key={index} className="rounded-2xl shadow-md bg-[#1d1b2a] text-white border border-purple-900">
                <CardContent className="p-6 text-lg font-medium flex flex-col items-center">
                  {service.icon}
                  <span>{service.title}</span>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contato Section */}
      <section className="py-16 bg-gradient-to-r from-[#150533] via-[#0e0b1f] to-[#051533] text-white text-center" id="contato">
        <h2 className="text-3xl font-bold mb-6">Vamos fazer sua marca vender mais?</h2>
        <p className="mb-6 text-lg">Entre em contato com a gente agora mesmo!</p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <a href="https://wa.me/5566992583505" target="_blank" rel="noopener noreferrer">
            <Button className="bg-green-500 hover:bg-green-600 text-white px-6 py-3 text-lg">WhatsApp</Button>
          </a>
          <a href="https://instagram.com/asyaxdigital" target="_blank" rel="noopener noreferrer">
            <Button className="bg-pink-500 hover:bg-pink-600 text-white px-6 py-3 text-lg">Instagram</Button>
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-6 bg-black text-center text-white text-sm">
        © 2025 Asyax Digital. Todos os direitos reservados.
      </footer>
    </div>
  );
}
